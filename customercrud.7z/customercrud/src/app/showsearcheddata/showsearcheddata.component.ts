import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../service/customer.service';
import { Customer } from '../model/customer';

@Component({
  selector: 'app-showsearcheddata',
  templateUrl: './showsearcheddata.component.html',
  styleUrls: ['./showsearcheddata.component.css']
})
export class ShowsearcheddataComponent implements OnInit {
searchedData:Customer[];

  constructor(private service:CustomerService) { }

  ngOnInit() {
    this.searchedData=this.service.getSearchedData();
  }

}
